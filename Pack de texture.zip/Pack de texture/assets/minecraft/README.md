# Tool Trims v3.0.7
This data pack adds 4 tool trim smithing templates, allowing you to trim weapons and tools. For more information or to check for new updates, visit [the project page on Modrinth](https://modrinth.com/datapack/tool-trims).

If you have found an issue or want to contribute with translations, visit the [Github repository for Tool Trims](https://github.com/thejoefly/ToolTrims).

## Changelog for v3.0.7
- Fixed issues where shovels didn't get migrated and didn't trigger advancements ([#14](https://github.com/thejoefly/ToolTrims/issues/14))
- Fixed the mineshaft loot table that didn't generate the bonce disk ([#13](https://github.com/thejoefly/ToolTrims/issues/13))
- Added the `tooltrims:get_items` function to 1.21.11+
- Added missing translations to the 1.21.1 and 1.20.1 versions
- Bug fixes for 1.20.1:
    - Now smithing and duplication recipes are unlocked when you get the templates
    - Migration of v2.x items should now work correctly
    - Fixed trimmed tools having z-fighting
    - Fixed crossbows showing a missing model when trimmed
    - Fixed issue causing texture/model errors in the Minecraft log

## Credits
**Contributors**
- BlueSheep (Trimmable Tridents)

**Translators**
- RandomKuchen (German)
- BlueSheep (Japanese)
- ESSENTIALS_GAMES (Polish)
- Slimy (Ukrainian and Russian)
- hellreign (Russian)
- ZhuinZ (Literary, Traditional and Simplified Chinese)
- aegeada (Turkish)

**Special Thanks**
- Coolsa (for the [Gui Generator](https://coolsa.github.io/mcCustomGuiGen/))
- ImpossibleEvan

## Copyrigh Notice
Copyright (C) 2023-2026 JoeFly. All rights reserved.